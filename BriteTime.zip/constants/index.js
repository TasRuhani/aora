import icons from "./icons";
import images from "./images";

export { icons, images };
